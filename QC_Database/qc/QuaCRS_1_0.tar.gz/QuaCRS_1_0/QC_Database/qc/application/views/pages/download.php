<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h1>Downloads</h1>
			<p>
				<br>
				<a href="http://bioserv.mps.ohio-state.edu/QuaCRS/QuaCRS_1_0.zip">QuaCRS v1.0</a> (Released 5/29/14)
				<ul>
					<li>Initial release</li>
				</ul>
			</p>

		</div>
	</div>
</div>
