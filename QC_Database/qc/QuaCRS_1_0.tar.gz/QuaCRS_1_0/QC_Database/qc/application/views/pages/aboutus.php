<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h1>About Us</h1>
			<p>
				<a href="http://www.cancer.osu.edu/about">The Ohio State University Comprehensive Cancer Center</a>
			</p>
                        <p>
   				<b>Maintainers</b>
				<br>
				<a href="mailto:esmailimokaram.1@buckeyemail.osu.edu">Nima Esmaili Mokaram</a>
				<br>
				<a href="mailto:Karl.Kroll@osumc.edu">Karl Kroll</a>
				<br>
				<a href="mailto:Alex.Pelletier@osumc.edu">Alex Pelletier</a>
                        </p>

		</div>
	</div>
</div>
