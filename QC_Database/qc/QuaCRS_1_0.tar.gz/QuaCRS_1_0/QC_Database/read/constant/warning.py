#WARNINGS
WRN_DB_TABLE_EXISTS="The table you are trying to create already exists in the database"
WRN_UPDATED_FILES="It is possible that some of the files have already been updated before you quit the program"

WRN_OVERWRITING="You are overwriting a cell in the table by uploading this data"
WRN_LOW_OVERWRITING="You are overwritng some data, HOWEVER, the columns you are overwriting are not filled in the table."

#OVERWRITING
# this question has to have the 3 choice of yes, yes to all, exit
OVERWRITING_Q="Would you like to continue and overwrite? or Exit?(Yes (Y), No! Exit(Q))?"
OVERWRITING_Q_YTA="Would you like to continue and overwrite? or Exit?(Yes (Y), Yes To All (YTA), Skip (S), No! Exit(Q))?"